const loginForm = document.getElementById("login-form");
const loginButton = document.getElementById("login-form-submit");
const loginErrorMsg = document.getElementById("login-error-msg");

loginButton.addEventListener("click", (e) => {
    e.preventDefault();
    const username = loginForm.username.value;
    const password = loginForm.password.value;
    db = openDatabase("users", "1.0", " Contains user information", 200000);
    db.transaction(function (tx) {
      tx.executeSql('SELECT * FROM uName WHERE Name LIKE %' + username + '%');
      var uName = results.rows.length, i;
      tx.executeSql('SELECT UserID FROM uName Where Name LIKE %' + username + '%')
      var id1 = results.rows.length, i
      tx.executeSql('SELECT * FROM pWord WHERE Pass LIKE %' + password + '%');
      var pWord = results.rows.length, i;
      tx.executeSql('SELECT UserID FROM pWord Where Pass LIKE %' + password + '%')
      var id2 = results.rows.length, i
    })
    if (username === uName && password === pWord && id1 === id2) {
        alert("You have successfully logged in.");
        location.reload();
    } else {
        loginErrorMsg.style.opacity = 1;
    }
})