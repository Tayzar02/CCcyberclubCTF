CREATE TABLE uName (
  Name varchar(255),
  UserID int
);
CREATE TABLE pWord (
  Pass varchar(255),
  UserID int
);
INSERT INTO uName (Name, UserID) VALUES ('admin', 001);
INSERT INTO uName (Name, UserID)
VALUES ('adam123', 002);
INSERT INTO uName (Name, UserID)
VALUES ('hacker456', 003);
INSERT INTO uName (Name, UserID)
VALUES ('test17', 004);
INSERT INTO uName (Name, UserID)
VALUES ('SonnyG4516', 005);
INSERT INTO uName (Name, UserID)
VALUES ('anon789', 006);
INSERT INTO uName (Name, UserID)
VALUES ('jBond1962', 007);

INSERT INTO pWord (Pass, UserID)
VALUES ('password', 001);
INSERT INTO pWord (Pass, UserID)
VALUES ('Blink182', 002);
INSERT INTO pWord (Pass, UserID)
VALUES ('CTF(Dr0pTabl3_passwrd)', 003);
INSERT INTO pWord (Pass, UserID)
VALUES ('Glad0s', 004);
INSERT INTO pWord (Pass, UserID)
VALUES ('correctbatteryhorsestaple', 005);
INSERT INTO pWord (Pass, UserID)
VALUES ('V', 006);
INSERT INTO pWord (Pass, UserID)
VALUES ('G0ldeneye', 007);
